import java.io.IOException;
import java.util.*;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class GameTable {

    private List<GameMap> maps;
    private List<Gamer> gamers;
    private Map<Integer, Object> history = new HashMap<>();
    private Map<Gamer, GameMap> table;
    private static Logger log = Logger.getLogger(GameTable.class.getName());

    public GameTable() {
        try {
            LogManager.getLogManager().readConfiguration(
                    GameTable.class.getClassLoader().getResourceAsStream("logging.properties"));
        } catch (IOException e) {
            System.err.println("Could not setup logger configuration: " + e.toString());
        }
        initialize();
    }

    public void initialize() {
        log.info("Start game\n");
        table = new HashMap<>();
        mapCreator();
        gamerCreator();
        go();
    }

    public void mapCreator() {
        GameMap sevenWorms = new GameMap("sevenWorms", "worms", "7", 0, true);
        GameMap sevenPeaks = new GameMap("sevenPeaks", "peaks", "7", 0, true);
        GameMap sevenBubbles = new GameMap("sevenBubbles", "bubbles", "7", 0, true);
        GameMap sevenBartisms = new GameMap("sevenBartisms", "bartisms", "7", 0, true);
        GameMap eightWorms = new GameMap("eightWorms", "worms", "8", 1, true);
        GameMap eightPeaks = new GameMap("eightPeaks", "peaks", "8", 1, true);
        GameMap eightBubbles = new GameMap("eightBubbles", "bubbles", "8", 1, true);
        GameMap eightBartisms = new GameMap("eightBartisms", "bartisms", "8", 1, true);
        GameMap nineWorms = new GameMap("nineWorms", "worms", "9", 2, true);
        GameMap ninePeaks = new GameMap("ninePeaks", "peaks", "9", 2, true);
        GameMap nineBubbles = new GameMap("nineBubbles", "bubbles", "9", 2, true);
        GameMap nineBartisms = new GameMap("nineBartisms", "bartisms", "9", 2, true);
        GameMap tenWorms = new GameMap("tenWorms", "worms", "10", 3, true);
        GameMap tenPeaks = new GameMap("tenPeaks", "peaks", "10", 3, true);
        GameMap tenBubbles = new GameMap("tenBubbles", "bubbles", "10", 3, true);
        GameMap tenBartisms = new GameMap("tenBartisms", "bartisms", "10", 3, true);
        GameMap jackWorms = new GameMap("jackWorms", "worms", "jack", 4, true);
        GameMap jackPeaks = new GameMap("jackPeaks", "peaks", "jack", 4, true);
        GameMap jackBubbles = new GameMap("jackBubbles", "bubbles", "jack", 4, true);
        GameMap jackBartisms = new GameMap("jackBartisms", "bartisms", "jack", 4, true);
        GameMap ladyWorms = new GameMap("ladyWorms", "worms", "lady", 5, true);
        GameMap ladyPeaks = new GameMap("ladyPeaks", "peaks", "lady", 5, true);
        GameMap ladyBubbles = new GameMap("ladyBubbles", "bubbles", "lady", 5, true);
        GameMap ladyBartisms = new GameMap("ladyBartisms", "bartisms", "lady", 5, true);
        GameMap kingWorms = new GameMap("kingWorms", "worms", "king", 6, true);
        GameMap kingPeaks = new GameMap("kingPeaks", "peaks", "king", 6, true);
        GameMap kingBubbles = new GameMap("kingBubbles", "bubbles", "king", 6, true);
        GameMap kingBartisms = new GameMap("kingBartisms", "bartisms", "king", 6, true);
        GameMap aceWorms = new GameMap("aceWorms", "worms", "ace", 7, true);
        GameMap acePeaks = new GameMap("acePeaks", "peaks", "ace", 7, true);
        GameMap aceBubbles = new GameMap("aceBubbles", "bubbles", "ace", 7, true);
        GameMap aceBartisms = new GameMap("aceBartisms", "bartisms", "ace", 7, true);
        maps = new ArrayList<GameMap>(
                Arrays.asList(
                        sevenWorms, sevenPeaks, sevenBubbles, sevenBartisms, eightWorms, eightPeaks, eightBubbles, eightBartisms,
                        nineWorms, ninePeaks, nineBubbles, nineBartisms, tenWorms, tenPeaks, tenBubbles, tenBartisms, jackWorms, jackPeaks, jackBubbles,
                        jackBartisms, ladyWorms, ladyPeaks, ladyBubbles, ladyBartisms, kingWorms, kingPeaks, kingBubbles, kingBartisms, aceWorms,
                        acePeaks, aceBubbles, aceBartisms
                )
        );
    }

    public void gamerCreator() {
        Gamer gamer1 = new Gamer("Irina", 10, 10);
        Gamer gamer2 = new Gamer("Nikita", 10, 10);
        Gamer gamer3 = new Gamer("Ilya", 10, 10);
        gamers = new ArrayList<Gamer>(Arrays.asList(gamer1, gamer2, gamer3));
    }

    public void go() {
        int range = 30;
        int index = 0;
        log.info("\nStart distribution maps for gamers");
        for (int i = 0; i < 30; i++) {
            index = (int) (Math.random() * range--);
            GameMap tmp = maps.get(index);
            if (gamers.get(0).getMaps().size() < 10) {
                gamers.get(0).addedCard(tmp);
                log.info("\nCard: " + tmp.getName() + " for player: " + gamers.get(0).getName());
            } else if (gamers.get(1).getMaps().size() < 10) {
                gamers.get(1).addedCard(tmp);
                log.info("\nCard: " + tmp.getName() + " for player: " + gamers.get(1).getName());
            } else if (gamers.get(2).getMaps().size() < 10) {
                gamers.get(2).addedCard(tmp);
                log.info("\nCard: " + tmp.getName() + " for player: " + gamers.get(2).getName());
            }
            maps.remove(index);
        }
        log.info("End maps for gamers\n");
    }

    public void goOne() {
        int range = gamers.get(0).getMaps().size();
        int index = 0;

        index = (int) (Math.random() * range);
        GameMap tmp = gamers.get(0).getMaps().get(index);

        table.put(gamers.get(0), tmp);
        gamers.get(0).getMaps().remove(tmp);
        log.info("\n" + gamers.get(0).getName() + " put on the table " + tmp.getName());
    }

    public void goTwo() {
        int range = gamers.get(1).getMaps().size();
        int index = 0;

        index = (int) (Math.random() * range);
        GameMap tmp = gamers.get(1).getMaps().get(index);

        table.put(gamers.get(1), tmp);
        gamers.get(1).getMaps().remove(tmp);
        log.info("\n" + gamers.get(1).getName() + " put on the table " + tmp.getName());
    }

    public void goThree() {

        int range = gamers.get(2).getMaps().size();
        int index = 0;

        index = (int) (Math.random() * range);
        GameMap tmp = gamers.get(2).getMaps().get(index);

        table.put(gamers.get(2), tmp);
        gamers.get(2).getMaps().remove(tmp);
        log.info("\n" + gamers.get(2).getName() + " put on the table " + tmp.getName());
    }

    public void goFoure() {
        int counter = 0;
        GameMap first = table.get(gamers.get(0));
        GameMap two = table.get(gamers.get(1));
        GameMap three = table.get(gamers.get(2));
        GameMap winCard = null;


        if (first.getMaste().equals(two.getMaste()) && first.getMaste().equals(three.getMaste())) {
            if (first.getPrice() < two.getPrice() && first.getPrice() < three.getPrice())
                if (two.getPrice() < three.getPrice())
                    winCard = three;
                else
                    winCard = two;
            else if (first.getPrice() > two.getPrice() && first.getPrice() > three.getPrice())
                winCard = first;
            else if (first.getPrice() < two.getPrice() && first.getPrice() > three.getPrice())
                winCard = two;
            else
                winCard = three;
        } else if (first.getMaste().equals(two.getMaste()) && !first.getMaste().equals(three.getMaste())) {
            if (first.getPrice() > two.getPrice())
                winCard = first;
            else
                winCard = two;
        } else if (first.getMaste().equals(three.getMaste()) && !first.getMaste().equals(two.getMaste())) {
            if (first.getPrice() > three.getPrice())
                winCard = first;
            else
                winCard = three;
        } else if (!first.getMaste().equals(three.getMaste()) && !first.getMaste().equals(two.getMaste()))
            winCard = first;

        GameMap finalWinCard = winCard;
        table.forEach((gamer, card) ->
                {
                    if (card.equals(finalWinCard)) {
                        gamer.plusPoints();
                    } else
                        gamer.minusPoints();
                }
        );
        log.info("\nWinner card: " + winCard.getName());
        String logMsg = "";
        for (Gamer cur : gamers)
            logMsg += "\nGamer: " + cur.getName() + " points: " + cur.getCountPoints() + " count maps: " + cur.getMaps().size();
        log.info(logMsg);
        history.put(counter, table);
        table.clear();
        counter++;
    }

    public void theGo() {
        goOne();
        goTwo();
        goThree();
        goFoure();
    }

    public void game() {
        for (int i = 0; i < 10; i++) {
            theGo();
            log.info("End " + i + " stake\n");
        }
    }

    public List<GameMap> getMaps() {
        return maps;
    }

    public List<Gamer> getGamers() {
        return gamers;
    }

    public static void main(String[] args) {
        GameTable a = new GameTable();
        a.game();
        log.info("\nEnd game");
    }
}
