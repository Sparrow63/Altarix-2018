import java.util.ArrayList;
import java.util.List;

public class Gamer {
    private String name;
    private int countMap;
    private int countPoints;
    private List<GameMap> maps;

    public Gamer(String name, int countMap, int countPoints) {
        maps = new ArrayList<GameMap>();
        this.name = name;
        this.countMap = countMap;
        this.countPoints = countPoints;
    }

    public void addedCard(GameMap card) {
        maps.add(card);
    }

    public String getName() {
        return name;
    }

    public void plusPoints() {
        ++countPoints;
    }

    public void minusPoints() {
        --countPoints;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCountMap() {
        return countMap;
    }

    public void setCountMap(int countMap) {
        this.countMap = countMap;
    }

    public int getCountPoints() {
        return countPoints;
    }

    public void setCountPoints(int countPoints) {
        this.countPoints = countPoints;
    }

    public List<GameMap> getMaps() {
        return maps;
    }

    public void setMaps(List maps) {
        this.maps = maps;
    }

}

